/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   FragTrap.hpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nkham <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/15 17:15:03 by nkham             #+#    #+#             */
/*   Updated: 2026/07/15 17:15:05 by nkham            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FRAGTRAP_HPP
#define FRAGTRAP_HPP

#include "ClapTrap.hpp"

class FragTrap:public ClapTrap
{
    public:
            FragTrap(void);
            FragTrap(std::string name);
            FragTrap(const FragTrap& other);
            FragTrap& operator=(const FragTrap& other);
            ~FragTrap();
            void highFivesGuys(void);
};

#endif