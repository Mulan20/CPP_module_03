/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nkham <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/15 17:00:16 by nkham             #+#    #+#             */
/*   Updated: 2026/07/15 17:00:17 by nkham            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ClapTrap.hpp"
#include "FragTrap.hpp"

int main(void) {
    std::cout << "=== Testing ClapTrap ===" << std::endl;
    ClapTrap a("Bob");
    a.attack("Kuku");
    a.takeDamage(5);
    a.beRepaired(2);
    
    std::cout << "\n=== Testing FragTrap ===" << std::endl;
    FragTrap c("Fraggy");
    c.attack("Target");
    c.takeDamage(40);
    c.beRepaired(15);
    c.highFivesGuys();
    
    std::cout << "\n=== Testing Construction Chain ===" << std::endl;
    FragTrap d("TestFrag");
    // Should see: ClapTrap → FragTrap
    
    return 0;
}