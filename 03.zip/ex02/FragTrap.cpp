/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   FragTrap.cpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nkham <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/15 17:14:54 by nkham             #+#    #+#             */
/*   Updated: 2026/07/15 17:14:56 by nkham            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "FragTrap.hpp"

FragTrap::FragTrap(void) : ClapTrap()
{
    this->hitPt = 100;
    this->energyPt = 100;
    this->attackPt = 30;
    std::cout << "The default constructor of FragTrap is created!\n";
}

FragTrap::FragTrap(std::string name) : ClapTrap(name)
{
    this->hitPt = 100;
    this->energyPt = 100;
    this->attackPt = 30;
    std::cout << "The constructor of FragTrap with " << this->name << " is created!\n";
}

FragTrap::FragTrap(const FragTrap& other) : ClapTrap(other)
{
    std::cout << "The copy constructor of FragTrap is called!\n";
}

FragTrap& FragTrap::operator=(const FragTrap& other)
{
    if (this != &other)
    {
        ClapTrap::operator = (other);
    }
    std::cout << "The FragTrap operator assignment is called\n";
    return *this;
}

FragTrap::~FragTrap()
{
    std::cout << "The FragTrap  " << this->name <<" is destructed!\n";
}

void FragTrap::highFivesGuys(void)
{
    std::cout << "Hey! Give me Highfives by " << this->name << "!\n";
}
