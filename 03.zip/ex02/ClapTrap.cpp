/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ClapTrap.cpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nkham <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/15 17:00:00 by nkham             #+#    #+#             */
/*   Updated: 2026/07/15 17:00:01 by nkham            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ClapTrap.hpp"

    ClapTrap::ClapTrap(void) :name("Default"), hitPt(10), energyPt(10), attackPt(0)
    {
        std::cout <<"The default claptrap contructor is created!\n";
    }

    ClapTrap::ClapTrap(std::string name) :name(name), hitPt(10), energyPt(10), attackPt(0)
    {
        std::cout << "The constructor is created with name " << this->name << "!\n";
    }

    ClapTrap::ClapTrap(const ClapTrap& other)
    {
        *this = other;
    }

    ClapTrap& ClapTrap::operator=(const ClapTrap& other)
    {
        if (this != &other)
        {
            this->name = other.name;
            this->hitPt = other.hitPt;
            this->energyPt = other.energyPt;
            this->attackPt = other.attackPt;
        }
        return *this;
    }

    ClapTrap::~ClapTrap()
    {
        std::cout << "The claptrap " << this->name <<" is destructed!" << std::endl;
    }

    void ClapTrap:: attack(const std::string& target)
    {
        if (hitPt == 0 || energyPt == 0)
            return;
    
        std::cout << "ClapTrap " << name << " attacks " << target << " causing " << attackPt << " points of damage.\n";
        energyPt--;
    }

    void ClapTrap:: takeDamage(unsigned int amount)
    {
        if (hitPt == 0)
        {
            std::cout << "Claptrap " << name << " is already destroyed\n";
            return;
        } 

        std::cout << "ClapTrap " << name << " takes " << amount << " points of damage!\n";
        if (amount >= hitPt)
            hitPt = 0;
        else
            hitPt -= amount;

    }

    void ClapTrap:: beRepaired(unsigned int amount)
    {
        if (hitPt == 0 || energyPt == 0)
        {
            std::cout << "Claptrap " << name << " is beyond repaired!\n";
            return ;
        }

        std::cout <<"Claptrap " << name << " repaied itself for " << amount << " hit points.\n";
        hitPt += amount;
        energyPt -= 1;
    }
