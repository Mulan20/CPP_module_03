/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nkham <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/15 17:00:16 by nkham             #+#    #+#             */
/*   Updated: 2026/07/15 17:00:17 by nkham            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ClapTrap.hpp"
#include "ScavTrap.hpp"

int main(void)
{
    std::cout << "=== Testing ClapTrap ===" << std::endl;
    ClapTrap a("Bob");
    a.attack("Kuku");
    a.takeDamage(5);
    a.beRepaired(2);
    
    std::cout << "\n=== Testing ScavTrap ===" << std::endl;
    ScavTrap b("Scavvy");
    b.attack("Enemy");
    b.takeDamage(30);
    b.beRepaired(10);
    b.guardGate();
    
    std::cout << "\n=== Testing construction chain ===" << std::endl;
    ScavTrap c("Test");
    // You should see: ClapTrap constructor called first, then ScavTrap
    
    return 0;
}
