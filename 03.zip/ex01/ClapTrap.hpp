/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ClapTrap.hpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nkham <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/15 17:00:09 by nkham             #+#    #+#             */
/*   Updated: 2026/07/15 17:00:11 by nkham            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef CLAPTRAP_HPP
#define CLAPTRAP_HPP

#include <iostream>

//we must change this to protected to let the derived class use it
class ClapTrap
{
    protected:
            std::string name;
            unsigned int hitPt;
            unsigned int energyPt;
            unsigned int attackPt;
            
    public:
            ClapTrap(void);
            ClapTrap(std::string name);
            ClapTrap(const ClapTrap& other);
            ClapTrap& operator=(const ClapTrap& other);
            ~ClapTrap();
            void attack(const std::string& target);
            void takeDamage(unsigned int amount);
            void beRepaired(unsigned int amount);
};
#endif
