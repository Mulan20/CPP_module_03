/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ScavTrap.cpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nkham <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/15 17:00:25 by nkham             #+#    #+#             */
/*   Updated: 2026/07/15 17:00:26 by nkham            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ScavTrap.hpp"

//this is how u will implement for the herited class function
ScavTrap::ScavTrap(void) : ClapTrap()
{
    this->hitPt = 100;
    this->energyPt = 50;
    this->attackPt = 20;
    std::cout << "The default constructor of Scavtrap is created!\n";
}

ScavTrap::ScavTrap(std::string name) : ClapTrap(name)
{
    this->hitPt = 100;
    this->energyPt = 50;
    this->attackPt = 20;
    std::cout << "The constructor of ScavTrap with " << this->name << " constructor is called!\n";
}

ScavTrap::ScavTrap(const ScavTrap& other) : ClapTrap(other)
{
    std::cout << "The copy constructor of ScavTrap is called!\n";
}

ScavTrap& ScavTrap::operator=(const ScavTrap& other)
{
    if (this != &other)
    {
        ClapTrap::operator=(other);
    }
    std::cout << "The ScavTrap operator assignment called!\n";
    return *this;
}

ScavTrap::~ScavTrap()
{
    std::cout << "The scavtrap is destructed!\n";
}

void ScavTrap::guardGate()
{
    std::cout << "Name: " << this->name << "\n";
    std::cout << "The scavtrap is now in gate keeper mode!\n";
}

void ScavTrap::attack(const std::string& target)
{
    if (this->hitPt == 0 || this->energyPt == 0)
            return;
    
    std::cout << "ScavTrap " << this->name << " attacks " << target << " causing " << this->attackPt << " points of damage.\n";
    this->energyPt--;
}
