/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ScavTrap.hpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nkham <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/15 17:00:35 by nkham             #+#    #+#             */
/*   Updated: 2026/07/15 17:00:36 by nkham            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SCAVTRAP_HPP
#define SCAVTRAP_HPP

//must include the header file of claptrap for the heritance
#include "ClapTrap.hpp"

//as the child class has inherited the base class, it does not
//need to redeclare the function or the attributes already in 
//the base class 

//you would only create new attributes if you need for the child class
//no association with the base class 
//or the overriden function in the child class 
class ScavTrap : public ClapTrap
{
    public:
            ScavTrap(void);
            ScavTrap(std::string name);
            ScavTrap(const ScavTrap& other);
            ScavTrap& operator=(const ScavTrap& other);
            ~ScavTrap();
            void guardGate();
            void attack(const std::string& target);
};
#endif
